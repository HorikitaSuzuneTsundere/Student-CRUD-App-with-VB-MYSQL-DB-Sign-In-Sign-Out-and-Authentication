﻿Public Class Form5
    Private Sub ProgressBar1_Click(sender As Object, e As EventArgs) Handles ProgressBar1.Click

    End Sub

    Private Sub ProgressBar2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(1)
        If ProgressBar1.Value = 100 Then
            Call User()
        ElseIf form2.TextBox1.Text = My.Settings.AdminUser And
        form2.TextBox2.Text = My.Settings.AdminPass Then
            Call Admin()

        End If
            Label2.Text = ProgressBar1.Value & (" &")
    End Sub
    Private Sub User()
        Me.Close()
        Form4.Show()
        Form4.Button6.Visible = False
        Form4.Button7.Visible = False
        Form4.Button8.Visible = False
        Form4.Button9.Visible = False
        Form4.Button11.Visible = False
    End Sub

    Private Sub Admin()
        Me.Close()
        Form4.Show()
        Form4.Text = "ADMIN"
        Form4.Label2.Visible = False
        Form4.Label3.Visible = False
        Form4.Label4.Visible = False
        Form4.Label5.Visible = False
    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class