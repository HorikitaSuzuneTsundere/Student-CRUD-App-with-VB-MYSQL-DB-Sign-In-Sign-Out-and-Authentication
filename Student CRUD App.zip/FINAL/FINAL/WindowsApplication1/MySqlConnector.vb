﻿Imports MySql.Data.MySqlClient
Module MySqlConnector
    Public mysqlcon As New MySqlConnection
    Public Sub connectdb()
        If mysqlcon.State = ConnectionState.Closed Then
            mysqlcon = New MySqlConnection("server=localHost; user id=root; password=; database=dbStudent")

        End If
    End Sub
    Public Sub disconnectdb()
        mysqlcon.Close()
    End Sub

End Module
