﻿Imports MySql.Data.MySqlClient
Public Class Form2

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim mysqlcon As New MySqlConnection
            Dim cmd As New MySqlCommand
            Dim dr As MySqlDataReader

            mysqlcon.ConnectionString = "server=localHost; user id=root; password=; database=dbStudent"
            cmd.Connection = mysqlcon
            mysqlcon.Open()
            cmd.CommandText = "SELECT UserUser,UserPass FROM tbluser WHERE UserUser = '" & TextBox1.Text & "' AND UserPass = '" & TextBox2.Text & "'"
            dr = cmd.ExecuteReader
            If dr.HasRows Then
                MsgBox("Welcome!")
                Me.Hide()
                Form5.Show()
                Form5.Timer1.Start()
            ElseIf TextBox1.Text = My.Settings.AdminUser And TextBox2.Text = My.Settings.AdminPass Then
                MsgBox("Welcome!")
                Me.Hide()
                Form5.Show()
                Form5.Timer1.Start()
            Else
                MsgBox("Invalid Username or Password")
                TextBox1.Text = ""
                TextBox2.Text = ""
            End If
        End If
    End Sub
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Form3.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
    Private Sub hawa()
        TextBox1.Text = ("")
        TextBox2.Text = ("")
    End Sub
End Class