﻿Imports MySql.Data.MySqlClient
Module Methods
    Public Sub displaydata()

        Call connectdb()
        Dim sql As String

        Dim ds As New DataSet

        sql = "SELECT * FROM tblstudinfo"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.Fill(ds, "tblstudinfo")
        Form1.DataGridView1.DataSource = ds.Tables("tblstudinfo")
        Call disconnectdb()

    End Sub
    Public Sub displaydata1()

        Call connectdb()
        Dim sql As String

        Dim ds As New DataSet

        sql = "SELECT * FROM tblstudroom"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.Fill(ds, "tblstudroom")
        Form6.DataGridView1.DataSource = ds.Tables("tblstudroom")
        Call disconnectdb()


    End Sub
    Public Sub displaydata2()

        Call connectdb()
        Dim sql As String

        Dim ds As New DataSet

        sql = "SELECT * FROM tblstudsched"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.Fill(ds, "tblstudsched")
        Form7.DataGridView1.DataSource = ds.Tables("tblstudsched")
        Call disconnectdb()


    End Sub
    Public Sub displaydata3()

        Call connectdb()
        Dim sql As String

        Dim ds As New DataSet

        sql = "SELECT * FROM tblcourse"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.Fill(ds, "tblcourse")
        Form8.DataGridView1.DataSource = ds.Tables("tblcourse")
        Call disconnectdb()


    End Sub
    Public Sub displaydata4()

        Call connectdb()
        Dim sql As String

        Dim ds As New DataSet

        sql = "SELECT * FROM tbluser"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.Fill(ds, "tbluser")
        Form9.DataGridView1.DataSource = ds.Tables("tbluser")
        Call disconnectdb()


    End Sub

    Public Sub save()

        If Form1.txtLN.Text = "" Or Form1.txtID.Text = "" Or Form1.txtFN.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to register/add this?", MsgBoxStyle.YesNo, "Register")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String
                Dim ds As New DataSet
                sql = "INSERT into tblstudinfo (StudID,StudLN,StudFN,StudAddress) VALUES (@StudID,@StudLN,@StudFN,@StudAddress)"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@StudID", Form1.txtID.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudLN", Form1.txtLN.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudFN", Form1.txtFN.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudAddress", Form1.txtAddress.Text)
                da.Fill(ds, "tblstudinfo")
                Call disconnectdb()
                MsgBox("Student Info Has been Added", MsgBoxStyle.Information, "Save")

            End If
        End If
        clears()
    End Sub
    Public Sub save1()

        If Form6.txtRoom.Text = "" Or Form6.txtID.Text = "" Or Form6.txtSched.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to register/add this?", MsgBoxStyle.YesNo, "Register")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String
                Dim ds As New DataSet
                sql = "INSERT into tblstudroom (RoomID,StudID,SchedID,Section) VALUES (@RoomID,@StudID,@SchedID,@Section)"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@RoomID", Form6.txtRoom.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudID", Form6.txtID.Text)
                da.SelectCommand.Parameters.AddWithValue("@SchedID", Form6.txtSched.Text)
                da.SelectCommand.Parameters.AddWithValue("@Section", Form6.txtSec.Text)
                da.Fill(ds, "tblstudroom")
                Call disconnectdb()
                MsgBox("Student Info Has been Added", MsgBoxStyle.Information, "Save")

            End If
        End If
        clears1()
    End Sub
    Public Sub save2()

        If Form7.txtSched.Text = "" Or Form7.txtID.Text = "" Or Form7.txtSub.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to register/add this?", MsgBoxStyle.YesNo, "Register")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String
                Dim ds As New DataSet
                sql = "INSERT into tblstudsched (SchedID,StudID,Subject,SubjectDes) VALUES (@SchedID,@StudID,@Subject,@SubjectDes)"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@SchedID", Form7.txtSched.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudID", Form7.txtID.Text)
                da.SelectCommand.Parameters.AddWithValue("@Subject", Form7.txtSub.Text)
                da.SelectCommand.Parameters.AddWithValue("@SubjectDes", Form7.txtDes.Text)
                da.Fill(ds, "tblstudsched")
                Call disconnectdb()
                MsgBox("Student Info Has been Added", MsgBoxStyle.Information, "Save")

            End If
        End If
        clears2()
    End Sub
    Public Sub save3()

        If Form8.txtCourse.Text = "" Or Form8.txtID.Text = "" Or Form8.txtName.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to register/add this?", MsgBoxStyle.YesNo, "Register")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String
                Dim ds As New DataSet
                sql = "INSERT into tblcourse (CourseID,StudID,CourseName,Track) VALUES (@CourseID,@StudID,@CourseName,@Track)"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@CourseID", Form8.txtCourse.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudID", Form8.txtID.Text)
                da.SelectCommand.Parameters.AddWithValue("@CourseName", Form8.txtName.Text)
                da.SelectCommand.Parameters.AddWithValue("@Track", Form8.txtTrack.Text)
                da.Fill(ds, "tblcourse")
                Call disconnectdb()
                MsgBox("Student Info Has been Added", MsgBoxStyle.Information, "Save")

            End If
        End If
        clears3()
    End Sub

    Public Sub recreate()

        If Form1.txtID.Text = "" Or Form1.txtAddress.Text = "" Or Form1.txtLN.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to update this?", MsgBoxStyle.YesNo, "Update")
            If x = vbNo Then
                Exit Sub
            Else

                Call connectdb()
                Dim sql As String
                Dim ds As New DataSet
                sql = "Update tblstudinfo set StudLN=@StudLN,StudFN=@StudFN,StudAddress=@StudAddress WHERE StudID=@StudID"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                Dim ID As Integer = Form1.DataGridView1.Rows(Form1.DataGridView1.CurrentRow.Index).Cells(0).Value
                da.SelectCommand.Parameters.AddWithValue("@StudID", Form1.txtID.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudLN", Form1.txtLN.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudFN", Form1.txtFN.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudAddress", Form1.txtAddress.Text)
                da.Fill(ds, "tblstudinfo")
                Call disconnectdb()



                MsgBox("Info. has been Updated!", MsgBoxStyle.Information, "Update")

            End If

        End If
        clears()
    End Sub
    Public Sub recreate1()

        If Form6.txtRoom.Text = "" Or Form6.txtID.Text = "" Or Form6.txtSched.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to update this?", MsgBoxStyle.YesNo, "Update")
            If x = vbNo Then
                Exit Sub
            Else

                Call connectdb()
                Dim sql As String
                Dim ds As New DataSet
                sql = "Update tblstudroom set StudID=@StudID,SchedID=@SchedID,Section=@Section WHERE RoomID=@RoomID"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                Dim ID As Integer = Form6.DataGridView1.Rows(Form6.DataGridView1.CurrentRow.Index).Cells(0).Value
                da.SelectCommand.Parameters.AddWithValue("@RoomID", Form6.txtRoom.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudID", Form6.txtID.Text)
                da.SelectCommand.Parameters.AddWithValue("@SchedID", Form6.txtSched.Text)
                da.SelectCommand.Parameters.AddWithValue("@Section", Form6.txtSec.Text)
                da.Fill(ds, "tblstudroom")
                Call disconnectdb()



                MsgBox("Info. has been Updated!", MsgBoxStyle.Information, "Update")

            End If

        End If
        clears1()
    End Sub
    Public Sub recreate2()

        If Form7.txtSched.Text = "" Or Form7.txtID.Text = "" Or Form7.txtSub.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to update this?", MsgBoxStyle.YesNo, "Update")
            If x = vbNo Then
                Exit Sub
            Else

                Call connectdb()
                Dim sql As String
                Dim ds As New DataSet
                sql = "Update tblstudsched set StudID=@StudID,Subject=@Subject,SubjectDes=@SubjectDes WHERE SchedID=@SchedID"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                Dim ID As Integer = Form7.DataGridView1.Rows(Form7.DataGridView1.CurrentRow.Index).Cells(0).Value
                da.SelectCommand.Parameters.AddWithValue("@SchedID", Form7.txtSched.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudID", Form7.txtID.Text)
                da.SelectCommand.Parameters.AddWithValue("@Subject", Form7.txtSub.Text)
                da.SelectCommand.Parameters.AddWithValue("@SubjectDes", Form7.txtDes.Text)
                da.Fill(ds, "tblstudsched")
                Call disconnectdb()



                MsgBox("Info. has been Updated!", MsgBoxStyle.Information, "Update")

            End If

        End If
        clears2()
    End Sub
    Public Sub recreate3()

        If Form8.txtCourse.Text = "" Or Form8.txtID.Text = "" Or Form8.txtName.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to update this?", MsgBoxStyle.YesNo, "Update")
            If x = vbNo Then
                Exit Sub
            Else

                Call connectdb()
                Dim sql As String
                Dim ds As New DataSet
                sql = "Update tblcourse set StudID=@StudID,CourseName=@CourseName,Track=@Track WHERE CourseID=@CourseID"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                Dim ID As Integer = Form8.DataGridView1.Rows(Form8.DataGridView1.CurrentRow.Index).Cells(0).Value
                da.SelectCommand.Parameters.AddWithValue("@CourseID", Form8.txtCourse.Text)
                da.SelectCommand.Parameters.AddWithValue("@StudID", Form8.txtID.Text)
                da.SelectCommand.Parameters.AddWithValue("@CourseName", Form8.txtName.Text)
                da.SelectCommand.Parameters.AddWithValue("@Track", Form8.txtTrack.Text)
                da.Fill(ds, "tblcourse")
                Call disconnectdb()



                MsgBox("Info. has been Updated!", MsgBoxStyle.Information, "Update")

            End If

        End If
        clears3()
    End Sub

    Public Sub view()
        Dim studentID As Integer
        studentID = Form1.DataGridView1.Rows(Form1.DataGridView1.CurrentRow.Index).Cells(0).Value
        Form1.txtLN.Text = Form1.DataGridView1.Rows(Form1.DataGridView1.CurrentRow.Index).Cells(1).Value
        Form1.txtFN.Text = Form1.DataGridView1.Rows(Form1.DataGridView1.CurrentRow.Index).Cells(2).Value
        Form1.txtAddress.Text = Form1.DataGridView1.Rows(Form1.DataGridView1.CurrentRow.Index).Cells(3).Value
    End Sub
    Public Sub view1()
        Dim roomID As Integer
        roomID = Form6.DataGridView1.Rows(Form6.DataGridView1.CurrentRow.Index).Cells(0).Value
        Form6.txtID.Text = Form6.DataGridView1.Rows(Form6.DataGridView1.CurrentRow.Index).Cells(1).Value
        Form6.txtSched.Text = Form6.DataGridView1.Rows(Form6.DataGridView1.CurrentRow.Index).Cells(2).Value
        Form6.txtSec.Text = Form6.DataGridView1.Rows(Form6.DataGridView1.CurrentRow.Index).Cells(3).Value
    End Sub
    Public Sub view2()
        Dim schedID As Integer
        schedID = Form7.DataGridView1.Rows(Form7.DataGridView1.CurrentRow.Index).Cells(0).Value
        Form7.txtID.Text = Form7.DataGridView1.Rows(Form7.DataGridView1.CurrentRow.Index).Cells(1).Value
        Form7.txtSub.Text = Form7.DataGridView1.Rows(Form7.DataGridView1.CurrentRow.Index).Cells(2).Value
        Form7.txtDes.Text = Form7.DataGridView1.Rows(Form7.DataGridView1.CurrentRow.Index).Cells(3).Value
    End Sub
    Public Sub view3()
        Dim courseID As Integer
        courseID = Form8.DataGridView1.Rows(Form8.DataGridView1.CurrentRow.Index).Cells(0).Value
        Form8.txtID.Text = Form8.DataGridView1.Rows(Form8.DataGridView1.CurrentRow.Index).Cells(1).Value
        Form8.txtName.Text = Form8.DataGridView1.Rows(Form8.DataGridView1.CurrentRow.Index).Cells(2).Value
        Form8.txtTrack.Text = Form8.DataGridView1.Rows(Form8.DataGridView1.CurrentRow.Index).Cells(3).Value
    End Sub
    Public Sub view4()
        Form9.txtUser.Text = Form9.DataGridView1.Rows(Form9.DataGridView1.CurrentRow.Index).Cells(1).Value
    End Sub


    Public Sub display()

        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT StudLN,StudFN,StudAddress FROM tblstudinfo"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.Fill(ds, "tblstudinfo")
        Form4.DataGridView1.DataSource = ds.Tables("tblstudinfo")
        Call disconnectdb()


    End Sub
    Public Sub display1()

        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT tblstudinfo.StudLN,tblstudroom.Section FROM tblstudinfo,tblstudroom WHERE tblstudinfo.StudID=tblstudroom.StudID"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.Fill(ds, "tblstudinfo,tblstudroom")
        Form4.DataGridView1.DataSource = ds.Tables("tblstudinfo,tblstudroom")
        Call disconnectdb()


    End Sub

    Public Sub display2()

        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT tblstudinfo.StudLN,tblstudsched.Subject,tblstudsched.SubjectDes FROM tblstudinfo,tblstudsched WHERE tblstudinfo.StudID=tblstudsched.StudID"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.Fill(ds, "tblstudinfo,tblstudsched")
        Form4.DataGridView1.DataSource = ds.Tables("tblstudinfo,tblstudsched")
        Call disconnectdb()


    End Sub

    Public Sub display3()

        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT tblstudinfo.StudLN,tblcourse.CourseName,tblcourse.Track FROM tblstudinfo,tblcourse WHERE tblstudinfo.StudID=tblcourse.StudID"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.Fill(ds, "tblstudinfo,tblcourse")
        Form4.DataGridView1.DataSource = ds.Tables("tblstudinfo,tblcourse")
        Call disconnectdb()


    End Sub

    Public Sub clears()
        Form1.txtID.Text = ("")
        Form1.txtLN.Text = ("")
        Form1.txtFN.Text = ("")
        Form1.txtAddress.Text = ("")
    End Sub
    Public Sub clears1()
        Form6.txtRoom.Text = ("")
        Form6.txtID.Text = ("")
        Form6.txtSched.Text = ("")
        Form6.txtSec.Text = ("")
    End Sub
    Public Sub clears2()
        Form7.txtSched.Text = ("")
        Form7.txtID.Text = ("")
        Form7.txtSub.Text = ("")
        Form7.txtDes.Text = ("")
    End Sub
    Public Sub clears3()
        Form8.txtCourse.Text = ("")
        Form8.txtID.Text = ("")
        Form8.txtName.Text = ("")
        Form8.txtTrack.Text = ("")
    End Sub
    Public Sub clears4()
        Form9.txtUser.Text = ("")

    End Sub
    Public Sub delete()
        If Form1.txtID.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to Delete/cancel this?", MsgBoxStyle.YesNo, "Delete")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String

                Dim ds As New DataSet

                sql = "DELETE from tblstudinfo WHERE StudID LIKE @StudID"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@StudID", "%" & Form1.txtID.Text & "%")
                da.Fill(ds, "tblstudinfo")
                Form1.DataGridView1.DataSource = ds.Tables("tblstudinfo")
                Call disconnectdb()
                displaydata()
                clears()
            End If

        End If
    End Sub
    Public Sub delete1()
        If Form6.txtRoom.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to Delete/cancel this?", MsgBoxStyle.YesNo, "Delete")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String

                Dim ds As New DataSet

                sql = "DELETE from tblstudroom WHERE RoomID LIKE @RoomID"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@RoomID", "%" & Form6.txtRoom.Text & "%")
                da.Fill(ds, "tblstudroom")
                Form6.DataGridView1.DataSource = ds.Tables("tblstudroom")
                Call disconnectdb()
                displaydata1()

            End If

        End If
        clears1()
    End Sub
    Public Sub delete2()
        If Form7.txtSched.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to Delete/cancel this?", MsgBoxStyle.YesNo, "Delete")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String

                Dim ds As New DataSet

                sql = "DELETE from tblstudsched WHERE SchedID LIKE @SchedID"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@SchedID", "%" & Form7.txtSched.Text & "%")
                da.Fill(ds, "tblstudsched")
                Form7.DataGridView1.DataSource = ds.Tables("tblstudsched")
                Call disconnectdb()
                displaydata2()

            End If

        End If
        clears2()
    End Sub
    Public Sub delete3()
        If Form8.txtCourse.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to Delete/cancel this?", MsgBoxStyle.YesNo, "Delete")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String

                Dim ds As New DataSet

                sql = "DELETE from tblcourse WHERE CourseID LIKE @CourseID"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@SchedID", "%" & Form8.txtCourse.Text & "%")
                da.Fill(ds, "tblcourse")
                Form8.DataGridView1.DataSource = ds.Tables("tblcourse")
                Call disconnectdb()
                displaydata3()

            End If

        End If
        clears3()
    End Sub
    Public Sub delete4()
        If Form9.txtUser.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to Delete/cancel this?", MsgBoxStyle.YesNo, "Delete")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String

                Dim ds As New DataSet

                sql = "DELETE from tbluser WHERE UserID LIKE @UserID"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@UserID", "%" & Form9.txtUser.Text & "%")
                da.Fill(ds, "tbluser")
                Form9.DataGridView1.DataSource = ds.Tables("tbluser")
                Call disconnectdb()
                displaydata4()

            End If

        End If
        clears4()
    End Sub
    Public Sub search()
        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT * FROM tblstudinfo WHERE StudLN LIKE @StudLN"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.SelectCommand.Parameters.AddWithValue("@StudLN", "%" & Form1.TextBox1.Text & "%")
        da.Fill(ds, "tblstudinfo")
        Form1.DataGridView1.DataSource = ds.Tables("tblstudinfo")
        Call disconnectdb()
        Form1.TextBox1.Text = ""
    End Sub
    Public Sub search0()
        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT StudLN,StudFN,StudAddress FROM tblstudinfo WHERE StudLN LIKE @StudLN"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.SelectCommand.Parameters.AddWithValue("@StudLN", "%" & Form4.TextBox1.Text & "%")
        da.Fill(ds, "tblstudinfo")
        Form4.DataGridView1.DataSource = ds.Tables("tblstudinfo")
        Call disconnectdb()
    End Sub
    Public Sub search01()
        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT tblstudinfo.StudLN,tblstudroom.Section FROM tblstudinfo,tblstudroom WHERE tblstudinfo.StudID=tblstudroom.StudID and Section LIKE @Section"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.SelectCommand.Parameters.AddWithValue("@Section", "%" & Form4.TextBox2.Text & "%")
        da.Fill(ds, "tblstudinfo,tblstudroom")
        Form4.DataGridView1.DataSource = ds.Tables("tblstudinfo,tblstudroom")
        Call disconnectdb()
    End Sub
    Public Sub search02()
        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT tblstudinfo.StudLN,tblstudsched.Subject,tblstudsched.SubjectDes FROM tblstudinfo,tblstudsched WHERE tblstudinfo.StudID=tblstudsched.StudID and Subject LIKE @Subject"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.SelectCommand.Parameters.AddWithValue("@Subject", "%" & Form4.TextBox3.Text & "%")
        da.Fill(ds, "tblstudinfo,tblstudsched")
        Form4.DataGridView1.DataSource = ds.Tables("tblstudinfo,tblstudsched")
        Call disconnectdb()
    End Sub
    Public Sub search03()
        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT tblstudinfo.StudLN,tblcourse.CourseName,tblcourse.Track FROM tblstudinfo,tblcourse WHERE tblstudinfo.StudID=tblcourse.StudID and Track LIKE @Track"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.SelectCommand.Parameters.AddWithValue("@Track", "%" & Form4.TextBox4.Text & "%")
        da.Fill(ds, "tblstudinfo,tblcourse")
        Form4.DataGridView1.DataSource = ds.Tables("tblstudinfo,tblcourse")
        Call disconnectdb()
    End Sub
    Public Sub search1()
        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT * FROM tblstudroom WHERE Section LIKE @Section"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.SelectCommand.Parameters.AddWithValue("@Section", "%" & Form6.TextBox1.Text & "%")
        da.Fill(ds, "tblstudroom")
        Form6.DataGridView1.DataSource = ds.Tables("tblstudroom")
        Call disconnectdb()
        Form6.TextBox1.Text = ""
    End Sub
    Public Sub search2()
        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT * FROM tblstudsched WHERE Subject LIKE @Subject"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.SelectCommand.Parameters.AddWithValue("@Subject", "%" & Form7.TextBox1.Text & "%")
        da.Fill(ds, "tblstudsched")
        Form7.DataGridView1.DataSource = ds.Tables("tblstudsched")
        Call disconnectdb()
        Form7.TextBox1.Text = ""
    End Sub
    Public Sub search3()
        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT * FROM tblcourse WHERE Track LIKE @Track"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.SelectCommand.Parameters.AddWithValue("@Track", "%" & Form8.TextBox1.Text & "%")
        da.Fill(ds, "tblcourse")
        Form8.DataGridView1.DataSource = ds.Tables("tblcourse")
        Call disconnectdb()
        Form8.TextBox1.Text = ""
    End Sub
    Public Sub search4()
        Call connectdb()
        Dim sql As String
        Dim ds As New DataSet
        sql = "SELECT * FROM tbluser WHERE UserID LIKE @UserID"
        Dim da As New MySqlDataAdapter(sql, mysqlcon)
        da.SelectCommand.Parameters.AddWithValue("@UserID", "%" & Form9.TextBox1.Text & "%")
        da.Fill(ds, "tbluser")
        Form9.DataGridView1.DataSource = ds.Tables("tbluser")
        Call disconnectdb()
        Form9.TextBox1.Text = ""
    End Sub


End Module
