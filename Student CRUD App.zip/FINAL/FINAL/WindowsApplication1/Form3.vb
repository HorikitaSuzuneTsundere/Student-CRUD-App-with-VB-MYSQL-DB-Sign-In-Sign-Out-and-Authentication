﻿Imports MySql.Data.MySqlClient
Public Class Form3
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Please check all the inputted fields!", MsgBoxStyle.Critical, "Error")
        Else
            Dim x = MsgBox("Do you want to create/add this?", MsgBoxStyle.YesNo, "Create")
            If x = vbNo Then
                Exit Sub
            Else
                Call connectdb()
                Dim sql As String
                Dim ds As New DataSet
                sql = "INSERT into tbluser (UserUser,UserPass) VALUES (@UserUser,@UserPass)"
                Dim da As New MySqlDataAdapter(sql, mysqlcon)
                da.SelectCommand.Parameters.AddWithValue("@UserUser", TextBox1.Text)
                da.SelectCommand.Parameters.AddWithValue("@UserPass", TextBox2.Text)
                da.Fill(ds, "tbluser")
                Call disconnectdb()
                MsgBox("Account Has been Added", MsgBoxStyle.Information, "Save")
                Me.Close()
                Form2.Show()
            End If
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        Form2.Show()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class